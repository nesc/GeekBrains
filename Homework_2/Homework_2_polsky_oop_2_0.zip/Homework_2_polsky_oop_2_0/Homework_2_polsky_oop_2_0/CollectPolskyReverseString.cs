﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework_2_polsky_oop_2_0
{
    class CollectPolskyReverseString
    {
        public string polskyString = "";
        public void AddCharToResult(string inChar)
        {
            this.polskyString += inChar + " ";
        }
    }
}
